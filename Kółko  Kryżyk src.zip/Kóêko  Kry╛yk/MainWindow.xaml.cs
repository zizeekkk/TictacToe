﻿using System.Windows;
using System.Windows.Controls;

namespace Kółko__Kryżyk
{
    public partial class MainWindow : Window
    {
        public bool Gracz { get; set; } // zmienna Gracz
        public int Counter { get; set; } // zmiennna ruch 
        public MainWindow()
        {
            InitializeComponent();
            NowaGra();
        }
        public void NowaGra() // zmienna Nowa Gra
        {
            Counter = 0;
            Button[] allb = new Button[9];
            allb[0] = B_0_0;
            allb[1] = B_0_1;
            allb[2] = B_0_2;
            allb[3] = B_1_0;
            allb[4] = B_1_1;
            allb[5] = B_1_2;
            allb[6] = B_2_0;
            allb[7] = B_2_1;
            allb[8] = B_2_2;
            foreach (Button b in allb)
            {
                b.IsEnabled = true;
                b.Content = "";
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e) // Algortym zmieniający kolejność ruchu po kliknięciu
        {
            Gracz ^= true; //Skrócona instrukcja 
            /*if (Gracz)
                Gracz = true;
            else
                Gracz = false;
            */
            Counter++;
            
            var button = sender as Button;

            button.Content = Gracz ? "X" : "O"; // Po kliknięciu zmienia znak oraz zmienia Gracza
            button.IsEnabled = false; // Po kiliknięciu uniemozliwia ponowne kliknięcie
            lbl_Ruch_Gracza_X_O.Content = Gracz ? "O" : "X"; //Opisuje dany Ruch dla gracza "X" lub "O"
       
            if (CheckIfPlayerWon()) // Jeśli ilość ruchów = do ilości zajętych pól przechodzi do funkcji sprawdzia
            {
                Counter = 9;
            }
        }

        private bool CheckIfPlayerWon() // Sprawdzanie. Czy na polach  są 3 znaki w jednej lini "X" lub "O"
        {
            if(B_0_0.Content.ToString() != string.Empty && B_0_0.Content == B_0_1.Content &&  B_0_1.Content == B_0_2.Content)
            {
                Wygrana();
                return false;
            }            
            if(B_1_0.Content.ToString() != string.Empty && B_1_0.Content == B_1_1.Content &&  B_1_1.Content == B_1_2.Content)
            {
                Wygrana();
                return false;
            } 
            if(B_2_0.Content.ToString() != string.Empty && B_2_0.Content == B_2_1.Content &&  B_2_1.Content == B_2_2.Content)
            {
                Wygrana();
                return false;
            }            
            if(B_0_0.Content.ToString() != string.Empty && B_0_0.Content == B_1_1.Content &&  B_1_1.Content == B_2_2.Content)
            {
                Wygrana();
                return false;
            }
            if(B_2_0.Content.ToString() != string.Empty && B_2_0.Content == B_1_1.Content &&  B_1_1.Content == B_0_2.Content)
            {
                Wygrana();
                return false;
            }
            if(B_0_0.Content.ToString() != string.Empty && B_0_0.Content == B_1_0.Content &&  B_1_0.Content == B_2_0.Content)
            {
                Wygrana();
                return false;
            }
            if (B_0_1.Content.ToString() != string.Empty && B_0_1.Content == B_1_1.Content && B_1_1.Content == B_2_1.Content)
            {
                Wygrana();
                return false;
            }
            if (B_0_2.Content.ToString() != string.Empty && B_0_2.Content == B_1_2.Content && B_1_2.Content == B_2_2.Content)
            {
                Wygrana();
                return false;
            }
            else if(Counter == 9)  // Jeśli 3 znaki "X" lub "O" nie są w tej samej lini oraz skończyły się pola ogłasza "REMIS"
            {
                MessageBox.Show("Remis","Koniec gry",MessageBoxButton.OK,MessageBoxImage.Information);     // Podczas osiągnięcia Remisu wyświetla komunikat
                NowaGra();
            }
            return false;
            
        }
        private void Wygrana() // zmienna Wygrana, podczas wygrania rundy dodaje +1 do licznika wygranego Gracza
        {
            MessageBox.Show("Wygrywa Gracz: " + (Gracz ? "X" : "O"),"Koniec Rundy",MessageBoxButton.OK,MessageBoxImage.Information);
            if (Gracz)
                lbl_Licznik_X.Content = ((int.Parse((string)lbl_Licznik_X.Content)) + 1).ToString();
            else
                lbl_Licznik_O.Content = ((int.Parse((string)lbl_Licznik_O.Content)) + 1).ToString();
            NowaGra();           
        }
        private void NowaGraButton_Click(object sender, RoutedEventArgs e)
        {
            NowaGra();
            Gracz = false;
            Counter = 0;
            lbl_Licznik_X.Content = "0"; // Resetuje licznik do wartości 0 Podczas użycia fukcji Nowa Gra
            lbl_Licznik_O.Content = "0"; // Resetuje licznik do wartości 0 Podczas użycia fukcji Nowa Gra
            lbl_Ruch_Gracza_X_O.Content = (Gracz ? "O" : "X"); // Podczas użycia fukcji Nowa Gra z przycisku atomatycznie pierwszy ruch uzyskuje "X"
        }

        private void WyjścieButton_Click(object sender, RoutedEventArgs e) // Przycisk Zakończenia Gry. Wyjście do Pulpitu
        {
            Close(); // Podczas uzycia funkcji Wyjście zamyka Grę
        }
        private void WyczyśćButton_Click(object sendeer, RoutedEventArgs e) // Przycisk Restartu Pola
        {
            if(Counter >= 5) // Po osiągnięciu 5 zajętych pól można wyczyścić pole
            {
                NowaGra();
            }
        }
        private void InformacjeButton_Click(object sender, RoutedEventArgs e)
        {

        }
        private void KKInformacjeButton_Click(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://mattomatti.com/pl/g01");
        }        
        private void ŹródłoButton_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
